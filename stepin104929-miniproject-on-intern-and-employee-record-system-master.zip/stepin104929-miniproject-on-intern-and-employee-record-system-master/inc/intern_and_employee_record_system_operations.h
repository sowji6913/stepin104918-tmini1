
#ifndef __INTERN_AND_EMPLOYEE_RECORD_STSTEM_OPERATIONS_H__
#define __INTERN_AND_EMPLOYEE_RECORD_STSTEM_OPERATIONS_H__

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <stdio_ext.h>

int EmployeeData(int operand1, int operand2);

int Addemployee(int operand1, int operand2);

int Viewallemployees(int operand1, int operand2);

int Modifyemployee(int operand1,int operand2);

int Deleteemployee(int operand1,int operand2);

int Exit(int operand1,int operand2);

int InternData(int operand1, int operand2);

int Addintern(int operand1, int operand2);

int Listintern(int operand1, int operand2);

int Modifyintern(int operand1,int operand2);

int Deleteintern(int operand1,int operand2);

int Exit(int operand1,int operand2);

#endif 
