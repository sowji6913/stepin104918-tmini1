#include <intern_and_employee_record_system_operations.h>

int EmployeeData(int operand1, int operand2)
{
    return operand1 + operand2;
}

int Addemployee(int operand1, int operand2)
{
    return operand1 - operand2;
}

/*int Viewallemployee(int operand1, int operand2)
{
    return operand1 * operand2;
}*/

int Modifyemployee(int operand1, int operand2)
{
    return operand1 * operand2;
}

int Deleteemployee(int operand1, int operand2)
{
    return operand1 * operand2;
}

int InternData(int operand1, int operand2)
{
    return operand1 * operand2;
}

int Addintern(int operand1, int operand2)
{
    return operand1 - operand2;
}

int Viewallinterns(int operand1, int operand2)
{
    return operand1 * operand2;
}

int Modifyintern(int operand1, int operand2)
{
    return operand1 * operand2;
}

int Deleteintern(int operand1, int operand2)
{
    return operand1 * operand2;
}

int Exit(int operand1, int operand2)
{
    if(0 == operand2)
        return 0;
    else
        return operand1 / operand2;
}
