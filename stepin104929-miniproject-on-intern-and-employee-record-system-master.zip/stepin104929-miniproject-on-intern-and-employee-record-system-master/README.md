# miniproject-on-intern-and-employee-record-system
#![cppcheck-action](https://github.com/Dimanth/stepin104929-miniproject-on-intern-and-employee-record-system/workflows/cppcheck-action/badge.svg)
#![C/C++ CI](https://github.com/Dimanth/stepin104929-miniproject-on-intern-and-employee-record-system/workflows/C/C++%20CI/badge.svg)
#![Unit testing](https://github.com/Dimanth/stepin104929-miniproject-on-intern-and-employee-record-system/workflows/Unit%20testing/badge.svg)
#[![Codacy Badge](https://app.codacy.com/project/badge/Grade/5f0fbeda09f140fe837f65499d6c700b)](https://www.codacy.com/gh/Dimanth/stepin104929-miniproject-on-intern-and-employee-record-system/dashboard?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=Dimanth/stepin104929-miniproject-on-intern-and-employee-record-system&amp;utm_campaign=Badge_Grade)
